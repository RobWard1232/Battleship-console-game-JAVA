import java.util.*;

// Board class extends Main
class Board extends Main{
  // Array of strings for collidables
  public String[] collidables = new String[10];
  public String[] nonCollidables = new String[10];

  // Variables for coordinates
  private int x;
  private int y;
  private int counter = 6;
  private List<Ship> playerShips;

  private int[][] ranXandY = new int[(int) (Math.random() * 15) + 0][(int) (Math.random() * 15) + 0];

  private int[][] test = new int[1][1];

  // Variable to hold board size
  public int xAndy = 15;

  // 2D array to hold board cells
  public String[][] bord = new String[xAndy][xAndy];

  // Board constructor
  public Board() {
    super();

    // Set collidable strings
    collidables[0] = "■";
    nonCollidables[1] = "O";
    nonCollidables[0] = "X";

    for (int i = 6; i < xAndy; i++) {
      counter++;
    }

    // Set initial board cells to "."
    for (int i = 0; i < xAndy; i++) {
      for (int l = 0; l < xAndy; l++) {
        bord[l][i] = "~";
      }
    }

    // Set bottom area to "~" to represent player's ships
    for (int i = 0; i < xAndy; i++) {
      for (int l = 0; l < xAndy; l++) {
        bord[l][i] = "~";
      }
    }
  }

  // Method to set a ship at given coordinates
  public void setShip(int x, int y) {
    bord[y][x] = collidables[0];
  }

  // attempt on getting my ships to be recieved by the game.
  //yuck
  public boolean getHitOrMiss(int j, int k, String scann) {

    if (scan.equals("nuke")) {
      //boolean m = battle.destroy(board, 7, 6);
    //if (m = true) {
      for (int i = 4; i <= 6; i++) {
        for (int r = 3; r <= 5; r++) {
          if ((ship1.getX() == i && ship1.getY() == r) ||
              (ship2.getX() == i && ship2.getY() == r) ||
              (ship3.getX() == i && ship3.getY() == r)) {
            bord[i][r] = "X";
          } else {
            bord[i][r] = "O";
          }
        }
      }
    
    } else if (scan.equals("sub")) { // not sure why it prints 6 times lol
      sub.destroy(ship1);
    } else {
      String[] coordinates = scann.split(", ");
      if (coordinates.length != 2) {
        return false;
      }
      int x = Integer.parseInt(coordinates[1]);
      int y = Integer.parseInt(coordinates[0]);

      // all commented out print statements are kinda for debug, if you uncomment them, they print weirdly and print a lot because they do it for each ship that is on the board.

      // Check if the entered y-coordinate is greater than 6
      if (x > 6) {
        System.out.println("Invalid input: y-coordinate cannot be greater than 6.");
        return false;
      }

      // If cell is within the board and empty, mark as miss
      if (y < 10 && x != j && y != k) {
        bord[x][y] = "O";
        // System.out.println("MISS!");
        return false;
      }
      // If cell is an enemy ship, mark as hit
      else if (x == j && y == k) {
        bord[x][y] = "X";
        // System.out.println("HIT!");
        return true;
      }
      // If cell is a player's ship or already marked as hit or miss, return false
      else if (bord[x][y].equals("X") || bord[x][y].equals("O")) {
        // System.out.println("Invalid input: the cell has already been guessed.");
        return false;
      } else {
        bord[x][y] = "X";
        // System.out.println("MISS!");
        return false;
      }
    }
    return false;
  }
  

  public boolean getEnemyHitOrMiss(int y, int x) {
    // Iterate over all of the player's ships
    for (int i = 0; i < 15; i++) {
      for (int l = 7; l < 14; l++) {
        // Check if the enemy guessed the same cell as the ship
        if (bord[y][x] == collidables[0]) {
          System.out.println("Gotcha!!");
          bord[y][x] = nonCollidables[0];
          return true;
        } else {
          bord[y][x] = nonCollidables[1];
          System.out.println("woops, I must have miss calculated..");
          // bord[y][x] = "O";
          return false;
        }
      }
    }
    return false;
  }

  public boolean getSub(String scan) {
    if (scan.equals("sub")) {
      return true;
    } else {
      return false;
    }
  }

  // Method to convert board to string
  public String toString() {
    String topGrid = "";
    String bottomGrid = "";

    // Iterate over board cells
    for (int row = 0; row < xAndy; row++) {
      for (int col = 0; col < xAndy; col++) {
        // If row is in top half of board, add to topGrid string
        if (row < xAndy / 2) {
          topGrid += bord[row][col];
        }
        // If row is in bottom half of board, add to bottomGrid string
        else {
          bottomGrid += bord[row][col];
        }
      }
      // Add newline character if row is finished
      if (row < xAndy / 2) {
        topGrid += "\n";
      } else {
        bottomGrid += "\n";
      }
    }

    return topGrid + "---------------"
        + "\n" + bottomGrid;
  }

  public String getCell(int row, int col) {
    return bord[row][col];
  }

  public void setCell(int row, int col, String value) {
    bord[row][col] = value;
  }

  // updates the board
  public void updateBoard(boolean hit) {
    if (hit) {
      System.out.println("Previous turn: HIT!");
    } else {
      System.out.println("Previous turn: MISS!");
    }
  }
}