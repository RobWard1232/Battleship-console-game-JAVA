import java.util.*;

public class Submarine extends Ship {

  public static int[] con = new int[10];

  public Submarine() {
    super();
  }

  // @Override
  public void destroy(Ship ship) {
    System.out.println("one ship is at: " + ship.getY() + ", " + ship.getX());
  }
}