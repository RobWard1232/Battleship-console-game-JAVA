import java.util.ArrayList;

public class Ship extends Board {
  private int size;
  private boolean horizontal;
  private ArrayList<int[]> coordinates;
  private int x;
  private int y;
  private int[] coordinate;

  public Ship() {
    super();
 
    this.coordinates = new ArrayList<int[]>();

    // Generate random coordinates for the ship
    x = (int) (Math.random() * 15);
    y = (int) (Math.random() * 7);

    if (bord[y][x].equals("X") || bord[y][x].equals("O")) {
      x = (int) (Math.random() * 15);
      y = (int) (Math.random() * 7);
    }

    // Add coordinates to ship
    // sean copied me for this one :)
    for (int i = 0; i < 1; i++) {
      coordinate = new int[2];
      coordinate[0] = x;
      coordinate[1] = y;
      this.coordinates.add(coordinate);

      // Set ship on board
      if (i == 0) {
        setShip(coordinate[0], coordinate[1]);
      } else {
        setShip(coordinate[0], coordinate[1] + i);
      }
    }

    // Place ship on board
    for (int[] coordinate : this.coordinates) {
      setShip(coordinate[0], coordinate[1]);
    }
  }

  public Ship(int x, int y) {
    super();

    this.coordinates = new ArrayList<int[]>();

    this.x = x;
    this.y = y;

    // Add coordinates to ship
    for (int i = 0; i < size; i++) {
      int[] coordinate = new int[2];
      coordinate[0] = x;
      coordinate[1] = y;
      this.coordinates.add(coordinate);
    
      // Set ship on board
      if (i == 0) {
        setShip(coordinate[0], coordinate[1]);
      } else {
        setShip(coordinate[0], coordinate[1] + i);
      }
    }

    // Place ship on board
    for (int[] coordinate : this.coordinates) {
      setShip(coordinate[0], coordinate[1]);
    }
  }

  public int getX() {
    return y;
  }

  public void setX(int x) {
    this.y = y;
  }

  public int getY() {
    return x;
  }

  public void setY(int y) {
    this.x = x;
  }

  public boolean destroy(boolean me) {
    if (me) {
      //System.out.println("Stink Stank Stunk");
      return true;
    } else if (!me) {
      return false;
    }
    return false;
  }
}