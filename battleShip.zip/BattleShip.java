//for now, think of the nuke command as a bigger sub almost

public class BattleShip extends Ship {
  public BattleShip() {
    super(); 
  } 
  // Method to destroy a ship at given coordinates
  public void destroy(Board board, int x, int y) {
    for (int i = 4; i < 7; i++) {
      for (int j = 3; j < 6; j++) {
        //for(Ship ship : ships) {
        boolean m = board.getHitOrMiss(j, i, scan);
        
        if (m == true) {
          board.bord[i][j] = "X";
          break;
        } 
				else {
          board.bord[i][j] = "O";
        }
        //}
      }
    }
  }
}