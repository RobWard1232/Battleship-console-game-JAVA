//Note: check BattleShip Note

import java.util.*;

class Main {
  //:( I know you will frown on this but it makes it soooo much easier
  public static int x2 = (int) (Math.random() * 14) + 0;
  public static int y2 = (int) (Math.random() * 8) + 7;
  public static BattleShip battle = new BattleShip();
  public static String scan;
  public static Submarine sub = new Submarine();
  public static Board board = new Board();
  public static Scanner scanner = new Scanner(System.in);
  public static Ship ship1 = new Ship(x2, y2);
  public static Ship ship2 = new Ship(x2, y2);
  public static Ship ship3 = new Ship(1, 1);
  public static ArrayList<Ship> ships = new ArrayList<Ship>();

  public static void main(String[] args) {
    boolean gameLoop = true;

    String[][] grid = new String[15][15];
    //int x = (int) (Math.random() * 9) + 7;
    //int y = (int) (Math.random() * 9) + 1;
    int counter = 0;
    int counted = 3;

    // create the ships and add them to the ships ArrayList

    ships.add(ship1);
    ships.add(ship2);
    ships.add(ship3);

    ArrayList<String> shipPositions = new ArrayList<String>();

    // random locations for now, just make sure if you change it in any way that all of the Y coordinates are above 7 otherwise it will be in the enemy field.
    board.setShip((int) (Math.random() * 14) + 1, 11);
    board.setShip((int) (Math.random() * 14) + 1, 7);
    board.setShip((int) (Math.random() * 14) + 1, 9);
    board.setShip((int) (Math.random() * 14) + 1, 10);
    board.setShip((int) (Math.random() * 14) + 1, 12);

    System.out.println("Welcome to my console BattleShip game. in order to play you type in: x, y in that exact fashion. if you want to use the nuke, than you type in nuke. if you want to use the submarine, than you type sub, enjoy :)\n oh and make sure that your coordinates do not go past 14 for the X axis and 6 for the Y axis.");

    // gameLoop that makes the whole thing run
    while (gameLoop) {
      // DEBUG TOOLS
      /*--------------------------------------------------------------
        System.out.print(ship.getY() + " ");
        System.out.println(ship.getX());
System.out.print(ship1.getY() + " ");
        System.out.println(ship1.getX());
      
System.out.print(ship2.getY() + " ");
        System.out.println(ship2.getX());
        System.out.print(ship3.getY() + " ");
        System.out.println(ship3.getX());
      ---------------------------------------------------------------*/

      System.out.println(board);
      
      System.out.print("Enter x,y coordinates: ");
      scan = scanner.nextLine();

      if (scan.equals("nuke")) {
        battle.destroy(board, 7, 6);
        for(int i = 4; i < 7; i++) {
          for(int l = 3; l < 6; l++) {
          boolean me = board.getHitOrMiss(i, l, scan);
            if (me = true) {
              counted--;
            } 
          }
        }
      } else if (scan.equals("sub")) { // not sure why it prints 6 times lol
      sub.destroy(ship1);
      }
      
      // enemy!
      x2 = (int) (Math.random() * 14) + 0;
      y2 = (int) (Math.random() * 8) + 7;

      // wtf
      boolean hit = false;
      for (Ship ship : ships) {
        if (board.getHitOrMiss(ship.getX(), ship.getY(), scan) == true) {
          hit = true;
          break;
        } else {
          board.getHitOrMiss(ship.getX(), ship.getY(), scan);
          hit = false;
        }
      }
      if (hit == true) {
        //System.out.println("Hit!");
        counted--;
        if (counted == 0) {
          System.out.println("You win!");
          gameLoop = false;
        }
      } else {
        //System.out.println("Miss!");
      }

      board.getEnemyHitOrMiss(y2, x2);
      // sub.destroy(ship1);
    }
  }
}